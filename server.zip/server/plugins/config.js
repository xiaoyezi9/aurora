module.exports={
    debug:true,//控制debug
    PED_SALT:'adadadadad',//用户密码加密密钥
    EXPIRE_SIN:60*60*24,//token过期时间
    PEIVATE_KEY:'asdadadada',//token加密密钥
}